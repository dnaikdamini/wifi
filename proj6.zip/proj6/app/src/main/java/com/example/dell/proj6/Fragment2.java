package com.example.dell.proj6;
import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class Fragment2 extends Fragment {
   Switch s1;
   TextView t1;
   LocationManager locationManager;
   boolean GpsStatus;
   Intent intent1,intent2;
   Context context;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_tab3,container,false);
        s1=(Switch)view.findViewById(R.id.switch3);
        t1=(TextView)view.findViewById(R.id.textView3);
        context=getActivity().getApplicationContext();
        CheckGpsStatus();
        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
              intent1=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
              startActivity(intent1);
            }
        });
        return view;

    }
    public void CheckGpsStatus(){
        locationManager=(LocationManager)context.getSystemService(Context.LOCATION_SERVICE);
        GpsStatus=locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if (GpsStatus==true){
            t1.setText("Location services enabled");
        }
        else {
            t1.setText("Location service disabled");
        }
    }
}
