package com.example.dell.proj6;

import android.bluetooth.BluetoothAdapter;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

public class Fragment1 extends Fragment {
    BluetoothAdapter ba;
    Switch s1;
    TextView t1;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_tab2,container,false);
        s1=(Switch)view.findViewById(R.id.switch2);
        t1=(TextView)view.findViewById(R.id.textView2);
        ba=BluetoothAdapter.getDefaultAdapter();
        if (ba.isEnabled()){
            ba.disable();
            t1.setText("bluetooth is currently switched off");
            s1.setText("switch on bluetooth");
        }
        if (ba.isEnabled()==false){
            ba.enable();
            t1.setText("bluetooth is currently switched on");
            s1.setText("switch off bluetooth");
        }
        s1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked)
                {
                    if (ba==null){
                        t1.setText("bluetooth adapter not found");
                        s1.setText("bluetooth disabled");
                        s1.setEnabled(false);
                    }
                    else
                    {
                        if (ba.isEnabled()){
                            t1.setText("bluetooth is currently switched on");
                            s1.setText("switch off bluetooth");
                        }
                        else {
                            t1.setText("bluetooth is currently switched off");
                            s1.setText("switch on bluetooth");
                        }
                    }
                }
                else {
                    if (ba.isEnabled()){
                        ba.disable();
                        t1.setText("bluetooth is currently switched off");
                        s1.setText("switch on bluetooth");
                    }
                    if (ba.isEnabled()){
                        ba.enable();
                        t1.setText("bluetooth is currently switched on");
                        s1.setText("switch off bluetooth");
                    }
                }
            }
        });
        return view;
    }
}
