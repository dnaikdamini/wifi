package com.example.dell.proj6;

import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Objects;

public class frag extends Fragment {
    private static int CAMERA_PIC_REQUEST=1;
    private ShortcutInfo data;
    View view;
    ImageView imageView;
    @TargetApi(Build.VERSION_CODES.N_MR1)
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_tab4,container,false);
        Button b=(Button)view.findViewById(R.id.button);
        imageView=(ImageView) view.findViewById(R.id.imageView);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent cameraIntent=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent,CAMERA_PIC_REQUEST);
            }
        });


        return view;
    }

    /* private static int CAMERA_PIC_REQUEST=1;
        private ShortcutInfo data;
        View view;
        @TargetApi(Build.VERSION_CODES.N_MR1)
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Nullable
        @Override
        public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
            View view=inflater.inflate(R.layout.fragment_tab4,container,false);
            Button b=(Button)view.findViewById(R.id.button);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent cameraIntent=new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(cameraIntent,CAMERA_PIC_REQUEST);
                }
            });

            return view;
        }*/
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        if (requestCode==CAMERA_PIC_REQUEST){
            Bitmap image=(Bitmap) Objects.requireNonNull(data.getExtras().get("data"));

            imageView.setImageBitmap(image);
        }
    }
}
